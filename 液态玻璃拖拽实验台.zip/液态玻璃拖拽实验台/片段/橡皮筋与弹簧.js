// 橡皮筋 + 接住速度的弹簧 · 画心人（simot0etf）· 液态玻璃拖拽实验台

/** 超出范围后的橡皮筋位移。x：手指超出的距离；d：最多能拉出多远；c：系数（iOS 逆向值约 0.55，越小越难拉） */
export const rubber = (x, d, c = 0.55) => Math.sign(x) * (1 - 1 / ((Math.abs(x) * c) / d + 1)) * d;

/** 手指位置 → 元素位置：范围内 1:1 跟手，超出部分走橡皮筋 */
export const follow = (raw, bound, d, c = 0.55) => {
  const e = Math.abs(raw) - bound;
  return e <= 0 ? raw : Math.sign(raw) * (bound + rubber(e, d, c));
};

/** 弹簧一步（半隐式欧拉）。duration / bounce 与 SwiftUI .spring(duration:bounce:) 同一套参数。
 *  s = {x, v}：x 是离家的位移，v 是速度（px/s）。松手时把手指速度赋给 v，弹簧就“接住”了你的力气。 */
export const springStep = (s, dt, duration = 0.5, bounce = 0.3, sub = 8) => {
  const w0 = (2 * Math.PI) / duration, z = 1 - bounce, h = dt / sub;
  for (let i = 0; i < sub; i++) { s.v += (-w0 * w0 * s.x - 2 * z * w0 * s.v) * h; s.x += s.v * h; }
  return s;
};
