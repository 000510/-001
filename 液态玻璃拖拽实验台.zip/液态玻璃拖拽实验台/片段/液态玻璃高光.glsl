// 液态玻璃：按下光晕 + 顺着速度拉长的高光（片元着色器核心）· 画心人（simot0etf）· 液态玻璃拖拽实验台
// G = (光晕中心 x, y, 半径, 强度)   V = (速度 vx, vy, 拉长量, -)   rim = 边缘遮罩（越靠边越接近 1）
vec3 touchGlow(vec3 col, vec2 p, vec4 G, vec4 V, float rim){
  vec2 dd = p - G.xy;
  float sp = length(V.xy);
  vec2 vh = sp > .01 ? V.xy / sp : vec2(1., 0.);
  float along = dot(dd, vh) / (1. + V.z);          // 顺着速度方向压缩坐标 = 光斑被拉长
  float perp  = dot(dd, vec2(-vh.y, vh.x));
  float w = exp(-(along*along + perp*perp) / (G.z*G.z));
  col = mix(col, vec3(1., .95, .86), clamp(G.w * w * .6, 0., .65));   // 暖白光晕，不用纯白，避免发灰发蓝
  col += G.w * .5 * rim * exp(-(along*along + perp*perp) / (G.z*G.z*6.)); // 光晕碰到边缘时，亮边也跟着亮
  return col;
}
// 菲涅尔亮边：法线 g 越朝向光 L，边越亮
vec3 fresnelRim(vec3 col, vec2 g, vec2 L, float rim, float k){
  return col + k * rim * (pow(max(dot(g, L), 0.), 2.) + .45 * pow(max(dot(g, -L), 0.), 3.));
}
