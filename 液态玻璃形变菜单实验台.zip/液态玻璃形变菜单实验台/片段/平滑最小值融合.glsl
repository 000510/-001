// 液态玻璃 · 融合：两块玻璃靠近时长出“脖子”，拉开到一定距离自动断开
// 画心人（simot0etf）

// 圆角矩形的有符号距离：p 相对中心，b 是半宽半高，r 是圆角
float sdRoundBox(vec2 p, vec2 b, float r) {
  r = min(r, min(b.x, b.y));
  vec2 q = abs(p) - b + r;
  return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r;
}

// 平滑最小值（多项式版）：k 越大，脖子越粗、越早连上；k = 0 时就是普通 min（只叠在一起）
float smin(float a, float b, float k) {
  if (k <= 0.01) return min(a, b);
  float h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0);
  return mix(b, a, h) - k * h * (1.0 - h);
}

// 用法：工具栏胶囊 + 水珠，一起当成一个形状
float scene(vec2 p, vec4 bar, float barR, vec4 drop, float dropR, float k) {
  float a = sdRoundBox(p - bar.xy, bar.zw, barR);
  float b = sdRoundBox(p - drop.xy, drop.zw, dropR);
  return smin(a, b, k); // < 0 在玻璃里，> 0 在外面
}

// 两个半径 R 的圆、圆心距离 D 时，脖子宽度（视频里那条曲线）：
//   neck = 2 * sqrt((R + k/4)^2 - D^2/4)，根号里小于 0 就是断开了
