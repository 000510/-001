// 液态玻璃 · 形变 + 内容过渡
// 画心人（simot0etf）

/** 阻尼弹簧 0 -> 1（可冲过头）。t 秒；k 刚度，c 阻尼。c 越小越弹 */
export function spring(t, k = 190, c = 15) {
  if (t <= 0) return 0;
  const w0 = Math.sqrt(k), z = c / (2 * w0);
  if (z < 1) {
    const wd = w0 * Math.sqrt(1 - z * z);
    return 1 - Math.exp(-z * w0 * t) * (Math.cos(wd * t) + (z * w0 / wd) * Math.sin(wd * t));
  }
  return 1 - Math.exp(-w0 * t) * (1 + w0 * t);
}

/** 同一块玻璃从 a 变到 b：宽、高、圆角、位置一起走同一个弹簧 */
export function morphRect(a, b, s) {
  const mix = (x, y) => x + (y - x) * s;
  return { x: mix(a.x, b.x), y: mix(a.y, b.y), w: mix(a.w, b.w), h: mix(a.h, b.h), r: Math.max(8, mix(a.r, b.r)) };
}

/** 飞行时顺着方向拉长：e 是飞行进度 0..1，amount 约 0.25；面积大致不变 */
export function flyStretch(w, h, e, amount = 0.25) {
  const s = 1 + amount * Math.sin(Math.PI * e);
  return { w: w / Math.sqrt(s), h: h * s };
}

/** 内容过渡：形状还在变时用模糊盖住，形状到位后再清楚出来
 *  shapeDone：形状完成度 0..1。返回给内容层用的 CSS */
export function contentStyle(shapeDone, maxBlur = 12) {
  const k = Math.min(1, Math.max(0, (shapeDone - 0.7) / 0.3)); // 最后 30% 才变清楚
  return { filter: `blur(${(1 - k) * maxBlur}px)`, opacity: Math.min(1, shapeDone * 2) };
}
