# AI 提示词 · 透明液态玻璃（边缘折射）

把下面的提示词连同 `index.html` 一起发给 AI（Claude / ChatGPT / Cursor 等）即可。

## 1. 套到我自己的页面上
```
这是一个"透明液态玻璃"效果的 HTML（附件 index.html）：卡片里放一份对齐的背景，
用 canvas 生成位移图（R=横向、G=竖向、128=不动，只有边缘一圈有位移），
再用 SVG feDisplacementMap 让边缘折射。请把这个效果用到我的页面上：
- 我的背景图是：____（换成你的图片路径）
- 需要做成玻璃的元素是：____（比如导航栏、按钮、弹窗）
- 保留 makeMap / setFilter / alignLens 三个函数的思路，元素尺寸变化时重新生成位移图
- 不要加磨砂模糊，保持中间清晰
```

## 2. 改成别的形状
```
基于附件 index.html 的透明液态玻璃，把卡片改成 ____（胶囊按钮 / 圆形 / 底部标签栏），
位移图里的圆角矩形 SDF 改成对应形状，边缘宽度 24px，折射强度 90。
```

## 3. 做成 React / Vue 组件
```
把附件 index.html 里的透明液态玻璃封装成一个 React 组件 <ClearGlass>，
props：width、height、radius、bezel（边缘宽度）、scale（折射强度）、curve（边缘弧度）、background（背景图）。
位移图按 props 缓存，尺寸变化时重算；每个实例用独立的 SVG filter id。
```

## 4. 让背后的动态内容也能折射
```
附件 index.html 用"复制一份背景"的方式做透明玻璃。我的背后是会滚动的页面/视频，
请改成在 Chromium 里用 backdrop-filter: url(#filter) 直接折射背后的内容，
并给 Safari/Firefox 写一个降级方案（例如半透明 + 细高光）。
```

---
提示词与 demo 作者：画心人（simot0etf）
