# 液态玻璃资源包 v2.0 · 真折射 + 四个控件

配套视频：《液态玻璃第二期：真折射 + 四个控件》（画心人 · AVF-BTN-007）

上一期（v1.0）做的是液态的四个动作：形变、回弹、融合、流光，玻璃本身用的是 CSS 磨砂。这一期补上玻璃这一半：用 WebGL 做真正的**折射、色散、细白边**，再做成四个能直接用的控件。

## 里面有什么

| 文件 | 内容 | 怎么用 |
|---|---|---|
| `demo/index.html` | 一块 WebGL 画布 + 5 块玻璃：可拖动卡片、底部标签栏、开关、滑块；右侧实时调参 | 双击用 Chrome / Edge / Safari 打开 |
| `react/LiquidGlass.tsx` | `LiquidGlassCanvas`、`useSpring`，以及 `GlassTabBar`、`GlassToggle`、`GlassSlider`、`GlassCard` | 复制进项目即可，零依赖（React 18+） |
| `shader/glass.vert` `shader/glass.frag` | 独立的着色器源码（WebGL 1） | 用在 Three.js / 原生 WebGL / 其他框架 |
| `参数表.md` | 折射、色散、白边、模糊、弹簧的推荐值和调节方向 | 调手感时对照 |
| `AI提示词.md` | 让 Claude / Cursor / 其他 AI 把这种玻璃用到你的界面上 | 复制粘贴，替换括号里的内容 |

## 30 秒上手（React）

```tsx
import {GlassTabBar, GlassToggle, GlassSlider, GlassCard} from './LiquidGlass';

const [tab, setTab] = useState(0);
const [on, setOn] = useState(true);
const [vol, setVol] = useState(0.4);

<GlassTabBar tabs={['首页', '发现', '消息', '我的']} value={tab} onChange={setTab} />
<GlassToggle checked={on} onChange={setOn} />
<GlassSlider value={vol} onChange={setVol} />
<GlassCard />
```

每个控件都接受 `paint` 参数：一个 `(ctx, w, h, t) => void` 函数，把你自己的背景（图片、渐变、文字）画进去，玻璃就会折射它。玻璃只有放在**有内容的背景**上才看得出效果。

## 它是怎么做的

1. 用 SDF（有向距离场）描述圆角矩形，算出每个像素离边缘多远。
2. 离边缘越近，采样位置沿法线往里偏得越多 → 折射，像凸透镜。
3. 红、绿、蓝三个通道分开采样，红往外、蓝往里 → 色散，颜色全部来自背景。
4. 内部只做约 1px 的 5 点模糊；外圈 1~2px 细白边；不加阴影。
5. 动作用弹簧：按压 k 300 / ζ 0.5（会过冲）；开关横向 ζ 0.6、纵向 ζ 0.7，两个方向不同步 → 果冻感。

## 两个坑

- 同屏玻璃别超过 5 块，手机上会掉帧（全屏 WebGL 每帧都在算）。
- 所有像素参数乘 `Math.min(devicePixelRatio, 2)`，3 倍屏不封顶会卡。本包已内置。

## 兼容性

需要 WebGL 1（所有现代浏览器）。不依赖 `backdrop-filter`。

## 致谢

感谢粉丝群里那位强烈要求加更、并分享了液态玻璃资料的朋友，这一期的方向来自他。本包代码由画心人按通用算法重新编写，不包含第三方源码。

## 许可

MIT（见 LICENSE）。个人和商业项目都可以用，也可以修改。

作者：画心人（simot0etf）。用法问题、定制需求，欢迎联系。
